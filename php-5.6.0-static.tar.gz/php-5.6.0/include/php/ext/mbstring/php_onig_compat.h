#ifndef _PHP_ONIG_COMPAT_H
#define _PHP_ONIG_COMPAT_H

#define re_pattern_buffer           php_mb_re_pattern_buffer
#define regex_t                     php_mb_regex_t
#define re_registers                php_mb_re_registers

#endif /* _PHP_ONIG_COMPAT_H */
