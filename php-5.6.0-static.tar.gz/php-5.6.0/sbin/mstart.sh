#!/bin/bash

killall nginx php-fpm 

rm -f /tmp/cores/*

ulimit -c unlimited

rm -Rf /home/rof/php-5.6.0/var/log/*
chown -R rof:rof /home/rof/php-5.6.0
su -l rof -s /bin/bash -c "cd  /home/rof/php-5.6.0; ./sbin/php-fpm -F  &"

rm -Rf  /home/rof/nginx/logs/*
mkdir -p  /home/rof/nginx/logs/run
chown -R rof:rof /home/rof/nginx
su -l rof -s /bin/bash -c "cd /home/rof/nginx; ./sbin/nginx &"

sleep 10

tail -f /home/rof/nginx/logs/symfony_error.log 

